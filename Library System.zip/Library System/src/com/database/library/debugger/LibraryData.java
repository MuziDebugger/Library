package com.database.library.debugger;
import java.sql.*;

public class LibraryData {
	public static final String DB_NAME = "libraryClients.db";
	 public static final String CONNECTION_STRING = "jdbc:sqlite:C:\\Users\\Muzi\\Desktop\\Oracle\\Projects\\SQL\\LibrarySystem\\" + DB_NAME;
	    public static final String TABLE_CLIENTS = "clients";
	    
	    public static final String COLUMN_CLIENT_ID = "clientId";
	    public static final String COLUMN_CLIENT_NAME = "fName";
	    public static final String COLUMN_CLIENT_SURNAME = "lName";
	    public static final String COLUMN_CLIENT_ADDRESS = "address";
	    public static final String COLUMN_WORK_TELEPHONE = "workTel";
	    public static final String COLUMN_HOME_TELEPHONE = "homeTel";
	    public static final String COLUMN_MOBILE_TELEPHONE = "mobileTel";
	    
	    public static void main(String[] args) {

       try {
           Connection conn = DriverManager.getConnection(CONNECTION_STRING);
           Statement statement = conn.createStatement();
           statement.execute("DROP TABLE IF EXISTS " + TABLE_CLIENTS);
           
           statement.execute("CREATE TABLE IF NOT EXISTS " + TABLE_CLIENTS +
   				" (" + COLUMN_CLIENT_ID + " integer, " +
   				COLUMN_CLIENT_NAME + " text, " + COLUMN_CLIENT_SURNAME + " text" +
   				COLUMN_CLIENT_ADDRESS + " text" + COLUMN_WORK_TELEPHONE + " integer" +
   				COLUMN_HOME_TELEPHONE + " integer" + COLUMN_MOBILE_TELEPHONE + " integer"+
                   ")");
   		
   		addClient(statement,001, "Frank", "Lucas", "66 Inkberry Gezina",12548122,112346782,81563023);
   		addClient(statement,023, "Lupe", "Francis", "442 WestVille Clarina",14421122,115312482,81364213);
   		addClient(statement,004, "Lerato", "Modiane", "82 Clubview Centurion",12548122,112830782,835123544);
   		
   		statement.execute("UPDATE " + TABLE_CLIENTS + " SET " +
                COLUMN_HOME_TELEPHONE + "=5566789" +
                " WHERE " + COLUMN_CLIENT_NAME + "='Frank'");
   		
           ResultSet results = statement.executeQuery("SELECT * FROM " + TABLE_CLIENTS);
           while(results.next()) {
    	    	System.out.println(results.getInt(COLUMN_CLIENT_ID) + " " +
    	    			           results.getString(COLUMN_CLIENT_NAME) + " " +
    	                           results.getString(COLUMN_CLIENT_SURNAME) + " " +
    	                           results.getString(COLUMN_CLIENT_ADDRESS + "" +
    	                           results.getInt(COLUMN_WORK_TELEPHONE) + " " +
    	                           results.getInt(COLUMN_HOME_TELEPHONE) + " " +
    	                           results.getInt(COLUMN_MOBILE_TELEPHONE) + " "));  
           }

           results.close();

           statement.close();
           conn.close();

//           Connection conn = DriverManager.getConnection(jdbc:sqlite:C:\\Users\\Muzi\\Desktop\\Oracle\\Projects\\SQL\\LibrarySystem\\clients.db");
//           Class.forName("org.sql.JDBC");
       } catch (SQLException e) {
           System.out.println("Something went wrong: " + e.getMessage());
           e.printStackTrace();
       }
   }

   private static void addClient(Statement statement, int clientID, String fName,
			String lName, String address, int workTel, int homeTel, int mobileTel) throws SQLException {
		    statement.execute("INSERT INTO " + TABLE_CLIENTS + 
		    		"(" + COLUMN_CLIENT_ID + ", " + COLUMN_CLIENT_NAME + "," +
		    		COLUMN_CLIENT_SURNAME + ", " + COLUMN_CLIENT_ADDRESS + "," +
		    		COLUMN_WORK_TELEPHONE + ", " + COLUMN_HOME_TELEPHONE + ", " +
		    		COLUMN_MOBILE_TELEPHONE + ")" 
		    		+ "VALUES('" + clientID + "'," + fName + ", '" + lName + ", '" 
		    		+ address + ", '" + workTel + ", '" + homeTel + ", '" + mobileTel + "')");
		    }
}
