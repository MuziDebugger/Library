package com.database.library.debugger;
import java.sql.*;
public class Library {
    public static void main(String[] args) {

        try {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Muzi\\Desktop\\Oracle\\Projects\\Library System\\libraryclient.db");
          conn.setAutoCommit(false);
            Statement statement = conn.createStatement();
            statement.execute("CREATE TABLE IF NOT EXISTS libraryClients " +
                              " (clientID INTEGER PRIMARY KEY(clientID), fName TEXT, lName TEXT, address TEXT, "
                              + "homeTel INTEGER, workTel INTEGER, mobileTel INTEGER)");
            
            statement.execute("INSERT INTO libraryClient (clientID, fName, lName, address, homeTel, "
            		+ "workTel, mobileTel ) "
            		+"VALUES('Frank', 'Lucas', '66 Inkberry Salie Street, Gezina, Pretoria', "
            		+ "0125481256, 0114786512, 0845327865)");

//            statement.execute("INSERT INTO libraryClient (clientID, fName, lName, address, homeTel, workTel, mobileTel) " +
//                    "VALUES('Frank', 'Lucas', '66 Inkberry Salie Street, Gezina, Pretoria', 0125481256, 0114786512, 0845327865)");
//            
            statement.execute("SELECT * FROM libraryClients");
            ResultSet results = statement.getResultSet();
            while(results.next()) {
                System.out.println(results.getInt("clientID") + " " +
                		           results.getString("fName") + " " +
                		           results.getString("lName") + " " +
                		           results.getString("address") + " " 
                		         + results.getInt("homeTel") + " " 
                		         + results.getInt("workTel") + " " 
                		         + results.getInt("mobileTel"));
            }

            results.close();

            statement.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Something went wrong: " + e.getMessage());
            e.printStackTrace();
        }
    }
}